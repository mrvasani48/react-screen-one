import PageRoutes from "./routes/PageRoutes";

const App = () => {
  return <PageRoutes />;
};

export default App;
